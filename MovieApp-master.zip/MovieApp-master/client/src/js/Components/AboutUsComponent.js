var React = require('react');

var AboutUsComponent = React.createClass({
  render: function() {
    return (
      <div>
        <h2>This is About Us page</h2>
      </div>
    );
  }
});

module.exports = AboutUsComponent;
