var React = require('react');

var ContactComponent = React.createClass({
  render: function() {
    return (
      <div>
        <h2>This is Contact page</h2>
      </div>
    );
  }
});

module.exports = ContactComponent;
