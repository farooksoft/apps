import React from 'react';

class Home extends React.Component {
  render(){
    return(
      <h2 className="text-center">
        Main Home content
      </h2>
    )
  }
}

export default Home;