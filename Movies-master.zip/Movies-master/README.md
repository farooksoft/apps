### Installing Dependencies

From within the root directory:

```sh
# Run in separate tabs
mongod

# and then...
npm install
bower install

node server/index.js

go to http://localhost:3000
```