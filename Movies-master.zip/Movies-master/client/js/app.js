angular.module('app', ['ui.router', 'app.core', 'app.components'])
  .config(config)
  .factory('AttachTokens', AttachTokens);


  function config($stateProvider, $urlRouterProvider, $locationProvider, $httpProvider) {
    
    $stateProvider
      .state('home', {
      	url: '/',
      	templateUrl: '/js/components/home/home.html',
      	controller: 'HomeController',
      	controllerAs: 'vm',
      	resolve: {
          moviesArray: function(movie) {
          	movie.getMovies()
          	  .then(function(data) {
                return data;
                console.log('data', data);
          	  });
          }
      	}
      })

      .state('movie', {
        url: '/movies/:movie',
        templateUrl: '/js/components/movie/movie.html',
        controller: 'MovieController',
        controllerAs: 'vm'
      })

      .state('login', {
        url: '/login',
        templateUrl: '/js/components/login/login.html',
        controller: 'LoginController',
        controllerAs: 'vm'
      })

      /*.state('logout', {
        url: '/logout',
        templateUrl: '',
        controller: 'LoginController'
      })
      */

      .state('user', {
        url: '/users/:user',
        templateUrl: '/js/components/user/user.html',
        controller: 'UserController',
        controllerAs: 'vm'
      });

  	// default uncaught routes to landing page
    $urlRouterProvider.otherwise('/');

    // enable HTML5 mode
    $locationProvider.html5Mode(true);

    $httpProvider.interceptors.push('AttachTokens');
  }


  function AttachTokens($window) {
    // this is an $httpInterceptor
    // its job is to stop all out going request
    // then look in local storage and find the user's token
    // then add it to the header so the server can validate the request
    return {
      request: function (config) {
        var jwt = $window.localStorage.getItem('movie.token');
        if (jwt) {
          config.headers.Authorization = 'Bearer ' + jwt;
          //config.headers['x-access-token'] = jwt;
        }
        //config.headers['Allow-Control-Allow-Origin'] = '*';
        return config;
      }
    };
  }
