angular.module('app.components')
  .controller('HomeController', HomeController)


  function HomeController($state, movie) {
    var vm = this;

    vm.movies;

    initialize();

    //////////////
    
    function initialize() {
      getMovies();
    }

    function getMovies() {
      movie.getMovies()
        .success(function(data) {
          vm.movies = data;
        });
    }
  }