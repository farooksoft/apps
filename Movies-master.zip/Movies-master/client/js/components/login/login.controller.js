angular.module('app.components')
  .controller('LoginController', LoginController)


  function LoginController($scope, $state, $window, auth, user) {
    
    var vm = this;
    vm.user = {
      username: '',
      password: ''
    };
    vm.login = login;

    //////////////
    

    function login() {
      console.log('login');
      var data = {
        username: vm.user.username,
        password: vm.user.password
      }

      auth.login(data)
        .success(function(res) {
          console.log('data', res);
          $window.localStorage.setItem('movie.token', res.token);
          $window.localStorage.setItem('movie.username', data.username);
          user.setCurrentUser();
          $scope.$emit('logged');
          $state.go('home');
        })
        .error(function(err) {
          console.log('error', err);
          $state.go('login');
        })
    }

    function logout() {
      auth.logout();
      $state.go('home');
    }
  }