angular.module('app.components')
  .controller('MovieController', MovieController)


  function MovieController($stateParams, movie) {
    var vm = this;

    vm.movie;
    vm.likeMovie = likeMovie;
    vm.shareMovie = shareMovie;

    initialize();

    //////////////
    
    function initialize() {
      getMovie();
    }

    function getMovie() {
      movie.getMovie($stateParams.movie)
        .success(function(data) {
          vm.movie = data;
          console.log('data', data);
        })
        .error(function(err) {
          console.log('error', err);
        })
    }

    function likeMovie() {
      movie.likeMovie(vm.movie.title)
        .success(function(data) {
          vm.movie.timesLiked += 1;
        });
    }

    function shareMovie() {
      movie.shareMovie(vm.movie.title, vm.sharedUsername, vm.message)
        .success(function(data) {
          vm.movie.timesShared += 1;
          vm.sharedUsername = '';
          vm.message = '';
        });
    }
  }