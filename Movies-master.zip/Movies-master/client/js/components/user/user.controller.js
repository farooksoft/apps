angular.module('app.components')
  .controller('UserController', UserController)


  function UserController($stateParams, user) {
    var vm = this;

    initialize();

    //////////////
    
    function initialize() {
      retrieveUser();
    }

    function retrieveUser() {
      user.retrieveUser($stateParams.user)
        .success(function(data) {
          vm.user = data;
          console.log('data', data);
        })
        .error(function(err) {
          console.log('error', err);
        })
    }
  }