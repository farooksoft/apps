angular.module('app.core')
  .factory('auth', auth)


  function auth($http, $window, user) {
  	var service = {
      login: login,
      logout: logout,
      isAuth: isAuth
  	};

  	return service;
  

    ///////////////////////////////////

    function login(data) {
      return $http({
      	method: 'POST',
      	url: '/api/auth/login',
        data: data
      })
    }

    function logout() {
      $window.localStorage.removeItem('movie.token');
      $window.localStorage.removeItem('movie.username');
      user.setCurrentUser(null);
    }

    function isAuth() {
      return !!$window.localStorage.getItem('movie.token');
    }
  }