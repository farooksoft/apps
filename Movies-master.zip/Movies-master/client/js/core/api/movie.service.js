angular.module('app.core')
  .factory('movie', movie)


  function movie($http, user) {
  	var service = {
      getMovie: getMovie,
      getMovies: getMovies,
      likeMovie: likeMovie,
      shareMovie: shareMovie
  	};

  	return service;
  

    ///////////////////////////////////

    function getMovie(id) {
      return $http({
      	method: 'GET',
      	url: '/api/movies/' + id
      });
    }

    function getMovies() {
      return $http({
      	method: 'GET',
      	url: '/api/movies'
      });
    }

    function likeMovie(id) {
      return $http({
        method: 'POST',
        url: '/api/movies/' + id + '/like',
        data: { username: user.getCurrentUser() }
      });
    }

    function shareMovie(id, sharedUsername, message) {
      return $http({
        method: 'POST',
        url: '/api/movies/' + id + '/share',
        data: { username: user.getCurrentUser(), sharedUsername: sharedUsername, message: message }
      });
    }
  }