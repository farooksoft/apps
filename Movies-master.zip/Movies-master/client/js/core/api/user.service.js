angular.module('app.core')
  .factory('user', user)


  function user($http, $window) {
    var user = null;
    initialize();

  	var service = {
      getCurrentUser: getCurrentUser,
      setCurrentUser: setCurrentUser,
      retrieveUser: retrieveUser
  	};

  	return service;

    ///////////////////////////////////

    function initialize() {
      setCurrentUser();
    }

    function retrieveUser(username) {
      return $http({
      	method: 'GET',
      	url: '/api/users/' + username
      })
    }

    function setCurrentUser() {
      user = $window.localStorage.getItem('movie.username');
    }

    function getCurrentUser() {
      return user;
    }
  }