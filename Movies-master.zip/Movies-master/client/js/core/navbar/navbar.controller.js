angular.module('app.core')
  .controller('NavbarController', NavbarController)


  function NavbarController($rootScope, $state, $window, auth, user) {
    var vm = this;
    
    vm.isLoggedIn = false;
    vm.username = '';

    vm.login = login;
    vm.logout = logout;
    vm.goToProfile = goToProfile;

    $rootScope.$on('logged', function(event, data) {
      getCurrentUser();
    })

    initialize();

    //////////////
    
    function initialize() {
      getCurrentUser();
    }

    function getCurrentUser() {
      vm.isLoggedIn = auth.isAuth();
      vm.username = user.getCurrentUser();
    }

    function login() {
      $state.go('login');
    }

    function logout() {
      auth.logout();
      $state.go('home');
      initialize();
    }

    function goToProfile() {
      $state.go('user', {user: vm.username})
    }
  }