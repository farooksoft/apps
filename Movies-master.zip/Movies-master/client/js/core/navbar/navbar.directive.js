angular.module('app.core')
  .directive('navbar', navbar);

  function navbar() {
    return {
      templateUrl: '/js/core/navbar/navbar.html',
      restrict: 'E',
      scope: false,
      controller: 'NavbarController',
      controllerAs: 'vm'
    };

  }