var Promise = require('bluebird');
var User = require('../user/userModel');
var utils = require('../../utils');
var jwt = require('jsonwebtoken');
var config = require('../../config.js');

module.exports = {

  login: function(req, res) {
    // find the user
	  User.findOne({
	    username: req.body.username
	  }, function(err, user) {

	    if (err) return res.status(500).json('Error authenticating');

	    if (!user) {
	      res.status(400).json('Authentication failed. User not found.');
	    } else {

	    	utils.comparePassword(req.body.password, user.password)
	    	  .then(function(isEqual) {

			      // check if password matches
			      if (!isEqual) {
			        res.status(400).json('Authentication failed. Wrong password.');
			      } else {

			        // if user is found and password is right
			        // create a token
			        var token = jwt.sign(user, config.secret, {
			          expiresInMinutes: 1440 // expires in 24 hours
			        });

			        // return the information including token as JSON
			        res.json({
			          success: true,
			          message: 'Authentication successful!',
			          token: token
			        });
			      }   
			    });
	    }
	  });
  }
};