var authController = require('./authController');


module.exports = function(router) {

  router.route('/api/auth/login')
    .post(authController.login);
};