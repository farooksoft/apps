var movieController = require('./movieController');


module.exports = function(router) {
  
  router.route('/api/movies')
    .get(movieController.getMovies);

  router.route('/api/movies/:movie')
    .get(movieController.getMovie)
    .put(movieController.editMovie);

  router.route('/api/movies/:movie/like')
    .post(movieController.likeMovie);

  router.route('/api/movies/:movie/share')
    .post(movieController.shareMovie);
};