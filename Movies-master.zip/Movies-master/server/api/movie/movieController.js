var Promise = require('bluebird');
var Movie = require('./movieModel');
var User = require('../user/userModel');
var utils = require('../../utils');
var io = require('../../index.js');

module.exports = {

  getMovie: function(req, res) {
    var movie = req.params.movie;
    console.log('movieID', movie);
    Movie.findOne({ title: movie }, function (err, movie) {
      if (err) return res.status(500).json('Error retrieving movie');
      if (!movie) return res.status(400).json('Failed to find movie with ID ' + movieID);
      return res.status(200).json(movie);
    });
  }, 

  getMovies: function(req, res) {
    Movie.find(function (err, movies) {
      if (err) return res.status(500).json('Error retrieving movies');
      return res.status(200).json(movies);
    });
  },

  editMovie: function(req, res) {
  },

  likeMovie: function(req, res) {
    var movie = req.params.movie;
    var user = req.body.username;
    Movie.findOneAndUpdate({ title: movie }, { $inc : {timesLiked : 1}, $push: {"usersLiked": user}}, function(err, movie) {
      if (err) return res.status(500).json('Error retrieving movie');
      if (!movie) return res.status(400).json('Failed to find movie with ID ' + movieID);

      User.findOneAndUpdate({ username: user }, { $push: {"moviesLiked": movie.title}}, function(err, user) {
        if (err) return res.status(500).json('Error retrieving movie');
        if (!user) return res.status(400).json('Failed to find user');
        res.status(201).json('Likes updated!');
      });
    });
  },

  shareMovie: function(req, res) {
    var movie = req.params.movie;
    var username = req.body.username;
    var message = req.body.message;
    var sharedUsername = req.body.sharedUsername;

    Movie.findOneAndUpdate({ title: movie }, { $inc : {timesShared : 1}, $push: {"usersShared": username}}, function(err, movie) {
      if (err) return res.status(500).json('Error retrieving movie');
      if (!movie) return res.status(400).json('Failed to find movie with ID ' + movieID);

      User.findOneAndUpdate({ username: username }, { $push: {"moviesShared": {title: movie.title, username: sharedUsername }}}, function(err, user) {
        if (err) return res.status(500).json('Error retrieving movie');
        if (!user) return res.status(400).json('Failed to find user that shared');
        
        var data = {title: movie.title, username: username, message: message };
        User.findOneAndUpdate({ username: sharedUsername }, { $push: {"moviesShared": data }}, function(err, user) {
          if (err) return res.status(500).json('Error retrieving movie');
          if (!user) return res.status(400).json('Failed to find the user who was shared');
          
          io.emit('shareData', data);
        
          res.status(201).json('Shares updated!');
        });
      });
    });
  }
};

