var mongoose = require('mongoose');
var db = require('../../db');

var movieSchema = mongoose.Schema({

  title: { type: String},

  description: { type: String},

  image: { type: String },
  
  timesLiked: { type: Number },

  usersLiked: [],

  timesShared: { type: Number },

  usersShared: []

});

var Movie = mongoose.model('Movie', movieSchema);

module.exports = Movie;