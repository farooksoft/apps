var Promise = require('bluebird');
var User = require('./userModel');
var utils = require('../../utils');


module.exports = {
  /**
   * Returns session user
   */
  getCurrentUser: function(req, res){
    res.status(200).json(req.user);
  },

  /**
   * Creates user from request and saves to database
   */
  createUser: function (req, res, next) {
    var username = req.body.username;
    var password = req.body.password;
    var newUser = new User({ 'username': username, 'password': password });
    newUser.save(function (err) {
      if (err) return res.status(500).json('Error saving user');
      return res.status(201).end();
    });

  },

  /**
   * Returns the database model associated with a username
   */
  getUser: function (req, res, next) {
    var username = req.params.username;
    User.findOne({'username': username}, function (err, user) {
      if (err) return res.status(500).json('Error retrieving user');
      if (!user) return res.status(400).json('Failed to find user ' + username);
      delete user['password'];
      return res.status(200).json(user);
    });
  },

  /**
   * Returns all user models of the database
   */
  getUsers: function (req, res, next) {
    User.find(function (err, users) {
      if (err) return res.status(500).json('Error finding users');
      return res.status(200).json(users);
    });
  },

  /**
   * Updates the user database model
   */
  editUser: function (req, res, next) {
    var username = req.params.username;
    var newData = req.body;

    User.update({'username': username}, newData, function (err, numberAffected, raw) {
      if (err) return res.status(500).json('Error updating user');
      if (!numberAffected) return res.status(400).json('Failed to edit user ' + username);
      return res.status(201).end();
    });
  }
};