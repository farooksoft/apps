var mongoose = require('mongoose');
var utils = require('../../utils');
var db = require('../../db');

var userSchema = mongoose.Schema({

  username: { type: String, required: true },

  password: { type: String, required: true },

  image: { type: String },

  moviesLiked: [],

  moviesShared: []
});

userSchema.pre('save', function(next) {
  var user = this;

  if (!user.isModified('password')) {
    return next();
  }

  utils.hashPassword(user.password)
    .then(function(hashedPassword) { 
      user.password = hashedPassword;
      next();
    });
});


var User = mongoose.model('User', userSchema);

module.exports = User;