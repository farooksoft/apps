module.exports = {
  'secret': 'thisisthesecret'
};