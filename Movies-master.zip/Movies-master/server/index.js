var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var morgan = require('morgan');
var config = require('./config.js');

// standard POST request body parser
app.use(bodyParser.urlencoded({ extended: false }));

// parse JSON posts
app.use(bodyParser.json());

// HTTP request logger middleware
app.use(morgan('combined'));

//set public files location
app.use(express.static(__dirname + '/../client/'));

app.set('secret', config.secret);

//require('./socket')(app);
require('./routes')(app);
require('./utils/seed')();


var server = require('http').createServer(app);

server.listen(3000, function() {
  console.log('server started');
});

var io = require('socket.io').listen(server);
module.exports = io;