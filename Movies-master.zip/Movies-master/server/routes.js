var router = require('express').Router();
var path = require('path');

module.exports = function(app) {
  
  require('./api/movie')(router);
  require('./api/user')(router);
  require('./api/auth')(router);

  router.get('/*', function(req, res) {
    res.sendFile(path.resolve(__dirname + '/../client/index.html'));
  });

  app.use(router);
};