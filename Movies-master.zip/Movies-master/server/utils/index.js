var bcrypt = require('bcrypt-nodejs');
var Promise = require('bluebird');


var hashPassword = function(passwordStr) {
  return new Promise(function(resolve, reject) {
    bcrypt.hash(passwordStr, null, null, function(err, hash) {
      if(err) {
      	return reject(err);
      }
      resolve(hash);
    });
  })
};

var comparePassword = function(passwordStr, passwordHashed) {
  return new Promise(function(resolve, reject) {
    bcrypt.compare(passwordStr, passwordHashed, function(err, res) {
      if(err) {
        return reject(err);
      }
      resolve(res);
    });
  });
}


module.exports = {
  hashPassword: hashPassword,
  comparePassword: comparePassword
}