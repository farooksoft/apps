var _ = require('lodash');

var mongoose = require('../db/index.js');
 mongoose.db.dropDatabase();

var User = require('../api/user/userModel');
var Movie = require('../api/movie/movieModel');

var seedDatabase = function() {
	console.log('Seeding database...');

	Movie.find({}).remove(function() {
	  Movie.create({
	    title: 'X-Men Origins: Wolverine',
	    description: "A look at Wolverine's early life, in particular his time with the government squad Team X and the impact it will have on his later years.",
	    image: 'http://i.movie.as/p/10052.jpg',
	    timesLiked: 10,
	    timesShared: 9
	  }, {
	    title: 'X-Men: Days of Future Past',
	    description: "The X-Men send Wolverine to the past in a desperate effort to change history and prevent an event that results in doom for both humans and mutants.",
	    image: 'http://upload.wikimedia.org/wikipedia/en/archive/0/0c/20150407071654!X-Men_Days_of_Future_Past_poster.jpg',
	    timesLiked: 4 ,
	    timesShared: 5
	  }, {
	    title: 'X-Men. La decisión final',
	    description: "When a cure is found to treat mutations, lines are drawn amongst the X-Men, led by Professor Charles Xavier, and the Brotherhood, a band of powerful mutants organized under Xavier's former ally, Magneto.",
	    image: 'http://blogs.estrellagalicia.es/rickydepor/files/2013/05/X_Men_3_La_Decision_Final-Caratula.jpg',
	    timesLiked: 18 ,
	    timesShared: 25
	  }, function(err, e1, e2, e3) {
	    console.log('\n\nCreated movies:\n', e1, e2, e3);

	    // Grab endpoint IDs to give to user
	    var endpointIDs = _.pluck([e1, e2, e3], '_id');

	    // Create users
	    User.find({}).remove(function() {
	      User.create({
	        username: 'Ruben',
	        password: '0000',
	        image: ''
	      }, {
	        username: 'Antonio',
	        password: '1234',
	        image: ''
	      }, function(err, u1, u2) {
	        console.log('\n\nCreated users:\n', u1, u2);
	        console.log('Finished seeding database');
	      });
	    });
	  });
	});

	User.find({}).remove(function() {
	});
};

module.exports = seedDatabase;