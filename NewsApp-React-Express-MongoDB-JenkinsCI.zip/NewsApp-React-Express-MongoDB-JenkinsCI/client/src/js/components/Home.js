var React= require('react');

var Home= React.createClass({
render: function(){
  return(
    <div >
    <h1>Hello User!!!! </h1>
    <h1>Hello User!!!! </h1>
    <h1>Hello User!!!! </h1>
    </div>
  );
}
});

module.exports=Home;
