export default {
    tabs: {
        backgroundColor: 'white',
        selectedTextColor: '#00bcd4',
        textColor: '#757575',
    },
    inkBar: {
        backgroundColor: '#00bcd4',
    },
};
