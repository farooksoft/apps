export simpleRestClient from './simple';
export jsonServerRestClient from './jsonServer';
export * from './types';
