export default (basePath, id) =>
    `${basePath}/${encodeURIComponent(id)}`
