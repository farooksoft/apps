Authentication Using JSON Web Token (JWT)
=========================================
In this part, we will continue to improve the application and add authentication to it.
