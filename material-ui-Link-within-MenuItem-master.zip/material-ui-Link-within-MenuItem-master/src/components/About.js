import React from 'react'

export default () => (
  <h1>
    You are now at ABOUT PAGE (<code>route: {'/about'}</code>)
  </h1>
)
