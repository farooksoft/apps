import React from 'react'

export default () => (
  <h1>
    You are now at HOME PAGE (<code>route: {'/'}</code>)
  </h1>
)
