module.exports = {
  movie: require('./Movie')
};
