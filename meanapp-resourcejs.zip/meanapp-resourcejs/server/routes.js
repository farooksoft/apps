module.exports = {
  'movie': require('./controllers/MovieController')
};
