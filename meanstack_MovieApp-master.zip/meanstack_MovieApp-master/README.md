# meanstack_MovieApp

this app is 85% done, i need to go back and fix it

## This application is running thanks to

#yeoman + nodejs + angularjs + expressjs
and a few more depencies 

I built or building this application following a youtube tutorial 
https://www.youtube.com/watch?v=OhPFgqHz68o by travis tidwell
# How to build a M.E.A.N web application

## this application was built for purely educational purposes.
I hope anytime in the future when i need reference, to go back and look at the code.
and it doesn't hurt to gain experience in a craft, that i want to build a future on.
