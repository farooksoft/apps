/**
 * Created by keltheceo on 3/24/15.
 */
module.exports = {
    '/movie': require('./controllers/MovieController')
};
