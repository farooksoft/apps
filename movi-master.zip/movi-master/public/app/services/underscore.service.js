angular.module('app')
    .constant('_', window._);