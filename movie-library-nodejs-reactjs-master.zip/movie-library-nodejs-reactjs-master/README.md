# Movie Library (Javascript Coding Challenge)

## Description
A single page application for managing a movie collection. The project description can be found  [here](docs/project_description.pdf).

## Launching the applicaton
To run the application, you will need to have mongoDB and Nodejs (with the npm packet manager) installed on your server.

Start the mongoDB service with:
```
sudo mongod
```
Clone the git repository and go to the project root. Install the project dependencies:
```
npm install
```

You are now ready to launch the application:
```
node app.js
```

View the application in a browser by navigating to:
```
http://localhost:3000
```

## Architechture
This application architechture is inspired by a full stack Javascript framework preceding the popularity of MEAN stack, Sailsjs. This is a minimal custom framework for this application that use mongoDB with Express, Nodejs and Reactjs to form a full stack (MERN)

- Nodejs: Server
- Express: View-Control layer
- MongoDB: Database
- EJS: Templating engine
- Reactjs: Front end modular UI library

## Dependencies

- "async": Chain functions asynchronously
- "body-parser": Send variables to the server and pass variables to the view
- "cookie-parser": Used for setting cookies
- "express": View-Control layer
- "fs": File System reader library
- "lodash": underscorejs, a common js helper library
- "method-override": Supports PUT and DELETE
- "waterline": DB ORM
- "request": Allows server-side HTTP requests
- “ejs”: Embedded Javascript, templating engine
