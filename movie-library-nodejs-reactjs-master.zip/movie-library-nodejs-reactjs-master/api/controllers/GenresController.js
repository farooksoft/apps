module.exports = {
	/**
	* Returns a complete list of genres
	*
	* @method collection
	* @param {object} req
	* @param {Object} res
	* @return {JSON}
	*/
	collection: function (req, res) {
		GenresService.getGenres(function (err, genres) {
			if (err) {
				return res.status(500).send(err)
			}

			return res.status(200).send({ 'genres': genres })
		})
	}
}