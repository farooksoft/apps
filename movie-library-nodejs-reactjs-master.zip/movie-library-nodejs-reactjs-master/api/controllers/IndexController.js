module.exports = {
	/**
	* Renders home page
	*
	* @method index
	* @param {object} req
	* @param {Object} res
	* @return {View}
	*/
	index: function (req, res) {
		// pass movie and genre data to view and render
		MoviesService.getFormattedMovies(function (err, movies) {
			if (err) { return res.status(500).send(err) }

			GenresService.getGenres(function (err, genres) {
				if (err) { return res.status(500).send(err) }
				return res.render('index', { 'movies': movies, 'genres': genres })
			})
		})
	}
}