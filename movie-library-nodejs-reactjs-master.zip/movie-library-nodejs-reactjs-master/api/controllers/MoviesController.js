module.exports = {
	/**
	* Returns the whole collection of movies formatted for views
	*
	* @method collection
	* @param {object} req
	* @param {Object} res
	* @return {JSON}
	*/
	collection: function (req, res) {
		MoviesService.getFormattedMovies(function (err, movies) {
			if (err) { return res.status(500).send(err) }
			return res.status(200).send({ 'movies': movies })
		})
	},

	/**
	* Adds a movie to collection, updates missing data for existing movies
	*
	* @method add
	* @param {object} req
	* @param {Object} res
	* @return {JSON}
	*/
	add: function (req, res) {
		var requestBody = req.body
		var movie, jsonString
		for (property in requestBody) {
			jsonString = property
		}
		movie = JSON.parse(jsonString)

		MoviesService.addToCollection(movie, function (err, responseJson) {
			if (err) { return res.status(500).send(err)}

			return res.status(200).send(responseJson)
		})
	}
}