module.exports = {
	attributes: {
		firstName: {
			type: 'string',
			maxLength: 60,
			required: true
		},
		lastName: {
			type: 'string',
			maxLength: 60
		},
		middleName: {
			type: 'string',
			maxLength: 60
		},
		movies: {
			collection: 'movies',
			via: 'actors'
		}
	},

	beforeCreate: function (values, next) {
		if (values.firstName) { values.firstName = values.firstName.toLowerCase() }
		if (values.lastName) { values.lastName = values.lastName.toLowerCase() }
		if (values.middleName) { values.middleName = values.middleName.toLowerCase() }
		next()
	},

	beforeUpdate: function (values, next) {
		if (values.firstName) { values.firstName = values.firstName.toLowerCase() }
		if (values.lastName) { values.lastName = values.lastName.toLowerCase() }
		if (values.middleName) { values.middleName = values.middleName.toLowerCase() }
		next()
	}
}