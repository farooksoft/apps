module.exports = {
	attributes: {
		name: {
			type: 'string',
			required: true,
			minLength: 1
		},
		movies: {
			collection: 'movies',
			via: 'genres'
		}
	},

	beforeCreate: function (values, next) {
		if (values.name) { values.name = values.name.toLowerCase() }
		next()
	},

	beforeUpdate: function (values, next) {
		if (values.name) { values.name = values.name.toLowerCase() }
		next()
	}
}