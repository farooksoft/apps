module.exports = {
	attributes: {
		title: {
			type: 'string',
			required: true,
			minLength: 1
		},
		rating: 'integer',
		year: 'integer',
		actors: {
			collection: 'actors',
			via: 'movies'
		},
		genres: {
			collection: 'genres',
			via: 'movies'
		}
	},

	beforeCreate: function (values, next) {
		if (values.title) { values.title = values.title.toLowerCase() }
		next()
	},

	beforeUpdate: function (values, next) {
		if (values.title) { values.title = values.title.toLowerCase() }
		next()
	}
}