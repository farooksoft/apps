
var _template = function (model) {
	if(model) model = model.toLowerCase()
	this.attributes = models[model].attributes

 	this.save = function (modelObj) {
        return {
            exec:function (cb) {
                if(typeof modelObj === 'array') {
                    async.eachSeries(modelObj,function (obj,call) {
                        obj.save(function (err) {
                            if(err) return call(err)
                            else return call()
                        })
                    },function (err) {
                        if(err) return cb(err)
                        return cb()
                    })
                }else{
                    modelObj.save(function (err) {
                        if(err) return cb(err)
                        return cb(null,modelObj)
                    })
                }
            }
        }
    }

	this.find = function (query, options) {
		var _self = this
		
		_self.base = models[model]
		_self.Parent = _self.base.find(query, options)
		_self.populates = [{field:null, model:model}]

		_self.returnObj = {
			populate:function (field) {
				_self.Parent = _self.Parent.populate(field)
				var attributes = _self.base.attributes
				var attribute = attributes[field]
				var _model = attributes[field].model || attributes[field].collection
				_self.populates.push({
					field:field,
					model:_model
				})
				return _self.returnObj
			},
			sort:function (str) {
				_self.Parent = _self.Parent.sort(str)
				return _self.returnObj
			},
			limit:function (num) {
				_self.Parent = _self.Parent.limit(num)
				return _self.returnObj
			},
			exec:function (cb, simple) {
				_self.Parent.exec(function (err,res) {
					if(err) return cb(err)
					return cb(null,res)
				})
			}
		}

		return _self.returnObj
	}

	this.findOne = function (query, options) {
		var _self = this
		
		_self.base = models[model]
		_self.Parent = _self.base.findOne(query, options)
		_self.populates = [{field:null, model:model}]

		_self.returnObj = {
			populate:function (field) {
				_self.Parent = _self.Parent.populate(field)
				var attributes = _self.base.attributes
				var attribute = attributes[field]
				var _model = attributes[field].model || attributes[field].collection
				_self.populates.push({
					field:field,
					model:_model
				})
				return _self.returnObj
			},
			sort:function (str) {
				_self.Parent = _self.Parent.sort(str)
				return _self.returnObj
			},
			exec:function (cb) {
				_self.Parent.exec(function (err,res) {
					if(err) return cb(err)
					return cb(null,res)
				})
			}
		}

		return _self.returnObj
	}

	this.count = function (query) {
		return{
			exec:function (cb) {
				models[model].count(query).exec(function (err,num) {
					if(err) return cb(err)
					return cb(null,num)
				})
			}
		}
	}

	this.update = function (query1,query2) {
		return {
			exec:function (cb) {
				models[model].update(query1,query2).exec(function (err,res) {
					if(err) return cb(err)
					return cb(null,res)
				})
			}
		}
	}

	this.create = function (query) {
		return {
			exec:function (cb) {
				models[model].create(query).exec(function (err,res) {
					if(err) return cb(err)
					return cb(null,res)
				})
			}
		}
	}

	this.createEach = function (query) {
		return {
			exec:function (cb) {
				if(!Array.isArray(query) || query.length === 0) return cb()
				models[model].createEach(query).exec(function (err,res) {
					if(err) return cb(err)
					return cb(null,res)
				})
			}
		}
	}

	this.destroy = function (queries) {
		return {
			exec:function (cb) {
				models[model].destroy(queries).exec(function (err,res) {
					if(err) return cb(err)
					return cb(null,res)
				})
			}
		}
	}

	this.destroyEach = function (queries) {
		return {
			exec:function (cb) {
				if(!queries.length) return cb()

				async.eachSeries(queries, function (query, call) {
					models[model].destroy(query).exec(function (err) {
						if(err) return call(err)
						else call()
					})
				}, function (err) {
					if(err) return cb(err)
					return cb()
				})
			}
		}
	}
}

module.exports = _template