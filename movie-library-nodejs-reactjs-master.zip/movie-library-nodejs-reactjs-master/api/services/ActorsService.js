module.exports = {
	/**
	* Converts a name string to an object
	*
	* @method toActorObject
	* @param {String} name
	* @return {Object}
	*/
	toActorObject: function (name) {
		var nameArray = name.split(' '),
			firstName = null,
			middleName = null,
			lastName = null

		switch (nameArray.length) {
			case 0:
				break

			case 1:
				firstName = nameArray[0]
				break

			case 2:
				firstName = nameArray[0]
				lastName = nameArray[1]
				break

			case 3:
				firstName = nameArray[0]
				middleName = nameArray[1]
				lastName = nameArray[2]
				break

			default:
				firstName = nameArray[0]

				middleName = '';
				for (i = 1; i < nameArray.length - 1; i++) {
					if (i != nameArray.length - 2) {
						middleName += nameArray[i] + ' '
					} else {
						middleName += nameArray[i]
					}
					
				}

				lastName = nameArray[nameArray.length - 1]
				break
		}

		if (firstName) firstName = firstName.toLowerCase()
		if (middleName) middleName = middleName.toLowerCase()
		if (lastName) lastName = lastName.toLowerCase()

		return {
			'firstName': firstName,
			'middleName': middleName,
			'lastName': lastName
		}
	}
}