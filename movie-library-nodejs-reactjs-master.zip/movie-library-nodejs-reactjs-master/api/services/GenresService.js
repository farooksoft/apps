module.exports = {
	/**
	* Returns a complete list of genres
	*
	* @method getGenres
	* @param {Function} cb
	* @return {Object Array}
	*/
	getGenres: function (cb) {
		$.Genres.find().sort('name asc').exec(function (err, genres) {
			if (err) {
				return cb(err)
			}

			genres.forEach(function (genre) {
				genre.name = genre.name.ucFirst()
			})
			return cb(null, genres)
		});
	},

	/**
	* Converts a genre name string to an object
	*
	* @method toGenreObject
	* @param {String} name
	* @return {Object}
	*/
	toGenreObject: function (name) {
		return { 'name': name.toLowerCase() }
	}
}