module.exports = {
	/**
	* Returns the complete collection of movies, formatted for views
	*
	* @method getFormattedMovies
	* @param {Function} cb
	* @return {Object Array}
	*/
	getFormattedMovies: function (cb) {
		var self = this

		$.Movies.find().populate('genres').populate('actors').exec(function (err, movies) {
			if (err) { return cb(err) }

			var formattedMovies = []
			movies.forEach(function (movie) {
				var formattedMovie = self.formatMovie(movie)
				formattedMovies.push(formattedMovie)
			})

			return cb(null, formattedMovies)
		})
	},

	/**
	* Formats a movie object for views
	*
	* @method formatMovie
	* @param {Object} movie
	* @return {Object}
	*/
	formatMovie: function (movie) {
		var formattedMovie = {},
			genreList = [],
			actorList = []

		if (movie.id) formattedMovie.id = movie.id
		if (movie.title) formattedMovie.title = movie.title.ucFirst()
		if (movie.year) formattedMovie.year = movie.year
		if (movie.rating) formattedMovie.rating = movie.rating

		movie.genres.forEach(function (genre) {
			genreList.push({ 'id': genre.id, 'name': genre.name.ucFirst() })
		})
		formattedMovie.genre = genreList

		movie.actors.forEach(function (actor) {
			var firstName = null,
				lastName = null,
				middleName = null,
				fullName = ''

			if (actor.firstName) { firstName = actor.firstName.ucFirst() }
			if (actor.lastName) { lastName = actor.lastName.ucFirst() }
			if (actor.middleName) { middleName = actor.middleName.ucFirst() }

			if (firstName) { fullName += firstName + ' ' }
			if (middleName) { fullName += middleName + ' ' }
			if (lastName) { fullName += lastName }
			fullName.trim()

			actorList.push({ 'id': actor.id, 'name': fullName })
		})
		formattedMovie.actors = actorList

		return formattedMovie
	},

	/**
	* Adds a new movie to the collection, updates missing data if it exists
	*
	* @method addToCollection
	* @param {Object} movieToAdd
	* @param {Function} callback
	* @return {Object}
	*/
	addToCollection: function (movieToAdd, callback) {
		var actors = movieToAdd.actors,
			genres = movieToAdd.genre,
			actorIdList = [],
			genreIdList = [],
			self = this

		var hasActors = actors && actors.length != 0,
			hasGenres = genres && genres.length != 0

		// helper function
	    var findOrCreateActor = function (actor, call) {
	    	if (hasActors) {
				async.eachSeries(actors, function (actor, cb) {
					var query = ActorsService.toActorObject(actor.name)

					$.Actors.findOne(query).exec(function (err, actorObj) {
						if (err) {
							return cb(err)
						} else if (actorObj) {
							actorIdList.push(actorObj.id)
							cb()
						} else {
							// in case of actor doesn't exit, create actor in DB
							$.Actors.create(query).exec(function (err, createdActor) {
								if (err) {
									return cb(err)
								} else {
									actorIdList.push(createdActor.id)
									cb()
								}
							})
						}
					})

				}, function (err) {
					if (err) { return call(err) }
					return call()
				})
			} else {
				call()
			}
	    }

	    // helper function
		var findGenres = function (genres, call) {
			if (hasGenres) {
				async.eachSeries(genres, function (genre, cb) {
					var query = GenresService.toGenreObject(genre.name)

					$.Genres.findOne(query).exec(function (err, genreObj) {
						if (err) {
							return cb(err)
						} else if (genreObj) {
							genreIdList.push(genreObj.id)
							cb()
						} else {
							cb()
						}
					})
				}, function (err) {
					if (err) { return call(err) }
					return call()
				})
			} else {
				call()
			}
	    }
		
		// helper function
		var numberOrNull = function (numString) {
			var numOrNull = parseInt(numString)
			if (isNaN(numOrNull)) { numOrNull = null }
			return numOrNull
		}


		// prepare movie data for create / update
		findOrCreateActor(actors, function (err) {
			if (err) { return callback(err) }

			findGenres(genres, function (err) {
				if (err) { return callback(err) }

				$.Movies.findOne({ 'title': movieToAdd.title.toLowerCase() }).populate('actors').populate('genres').exec(function (err, movie) {
					if (err) { return callback(err) }

					// if movie exits, update missing movie data
					if (movie) {
						var updateMovie = false
						if (!movie.year && movieToAdd.year) {
							movie.year = numberOrNull(movieToAdd.year)
							updateMovie = true
						}
						if (!movie.rating && movieToAdd.rating) {
							movie.rating = numberOrNull(movieToAdd.rating)
							updateMovie = true
						}

						if (hasActors) {
							actorIdList.forEach(function (actorId) {
								var actorExists = false;
								movie.actors.forEach(function (actor) {
									if (!actorExists) actorExists = actor.id == actorId
								})
								if (!actorExists) {
									movie.actors.add(actorId)
									updateMovie = true
								}
								
							})	
						}
						if (hasGenres) {
							genreIdList.forEach(function (genreId) {
								var genreExists = false
								movie.genres.forEach(function (genre) {
									if (!genreExists) genreExists = genre.id == genreId
								})
								if (!genreExists) {
									movie.genres.add(genreId)
									updateMovie = true
								}
								
							})	
						}
						
						if (updateMovie) {
							movie.save(function (err) {
								if (err) {
									return callback(err)
								}
								$.Movies.findOne(movie.id).populate('actors').populate('genres').exec(function (err, populatedMovie) {
									if (err) {
										return callback(err)
									}
									return callback(null, { 'movie': self.formatMovie(populatedMovie), 'message': 'Movie data updated!' })
								})
							})
						} else {
							return callback(null, { 'movie': self.formatMovie(movie), 'message': 'Nothing to save.' })
						}
					}

					
					// otherwise add movie
					else {
						var newMovie = {
							'title': movieToAdd.title,
							'year': numberOrNull(movieToAdd.year),
							'rating': numberOrNull(movieToAdd.rating)
						}

						$.Movies.create(newMovie).exec(function (err, createdMovie) {
							if (err) { return callback(err) }

							if (hasActors) {
								actorIdList.forEach(function (actorId) {
									createdMovie.actors.add(actorId)
								})
							}
							if (hasGenres) {
								genreIdList.forEach(function (genreId) {
									createdMovie.genres.add(genreId)
								})
							}
							
							createdMovie.save(function (err) {
								if (err) { return callback(err) }

								$.Movies.findOne(createdMovie.id).populate('actors').populate('genres').exec(function (err, populatedMovie) {
									if (err) { return callback(err) }

									return callback(null, { 'movie': self.formatMovie(populatedMovie), 'message': 'Movie added to collection!' })
								})
								
							})
						})
					}
				})
			})

		})
	}
}