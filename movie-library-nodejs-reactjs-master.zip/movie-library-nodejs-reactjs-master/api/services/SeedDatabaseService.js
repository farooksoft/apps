module.exports = {
	/**
	* Initializes sample data first time application is launched
	*
	* @method seedDatabase
	* @param {Function} cb
	*/
	seedDatabase: function (cb) {
		var self = this;

		this.seedGenres(function () {
			self.seedActors(function () {
				self.seedMovies(cb)
			})
		})
	},

	/**
	* Adds genres from /json/genres.json
	*
	* @method seedGenres
	* @param {Function} cb
	*/
	seedGenres: function (cb) {
		$.Genres.count().exec(function (err, genreCount) {
			if (err) { return cb(err) }

			if (genreCount == 0) {
				console.log('---------- First time launching application: Initializing, please wait... ----------', '\n')
				console.log('> Seeding Database: Creating genres')

				var genres = require('../../json/genres.json')

				var loop = function (genre, next) {
					genre.name = genre.name.toLowerCase()
					$.Genres.create(genre).exec(function (createError, createdGenre) {
						if (err) { next(createError) }
						next();
					})
				}

				var finished = function (seedError) {
					if (seedError) { return cb(seedError) }
					return cb()
				}

				async.eachSeries(genres, loop, finished)
			} else {
				return cb()
			}
		})
	},

	/**
	* Adds actors from /json/actors.json
	*
	* @method seedActors
	* @param {Function} cb
	*/
	seedActors: function (cb) {
		$.Actors.count().exec(function (err, actorCount) {
			if (err) { return cb(err) }

			if (actorCount == 0) {
				console.log('> Seeding Database: Creating actors')

				var actors = require('../../json/actors.json')

				var loop = function (actor, next) {
					if (actor.firstName) { actor.firstName = actor.firstName.toLowerCase() }
					if (actor.middleName) { actor.middleName = actor.middleName.toLowerCase() }
					if (actor.lastName) { actor.lastName = actor.lastName.toLowerCase() }

					$.Actors.create(actor).exec(function (createError, createdActor) {
						if (err) { next(createError) }
						next();
					})
				}

				var finished = function (seedError) {
					if (seedError) { return cb(seedError) }
					return cb()
				}

				async.eachSeries(actors, loop, finished)
			} else {
				return cb()
			}
		})
	},

	/**
	* Adds movies from /json/movies.json
	*
	* @method seedMovies
	* @param {Function} cb
	*/
	seedMovies: function (cb) {
		$.Movies.count().exec(function (err, actorMovies) {
			if (err) { return cb(err) }

			if (actorMovies == 0) {
				console.log('> Seeding Database: Creating movies','\n')
				
				var movies = require('../../json/movies.json')

				var loop = function (movie, next) {
					MoviesService.addToCollection(movie, next)
				}

				var finished = function (seedError) {
					if (seedError) { return cb(seedError) }
					console.log('---------- First time launching application: Initialization complete, launching application... ----------', '\n')
					return cb()
				}

				async.eachSeries(movies, loop, finished)
			} else {
				return cb()
			}
		})
	}
}