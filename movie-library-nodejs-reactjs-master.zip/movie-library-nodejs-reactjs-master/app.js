var express = require('express')

var path = require('path') // used to concatenate paths 

var cookieParser = require('cookie-parser') // used for request sent to server
var methodOverride = require('method-override') // allows usage of PUT and DELETE
var bodyParser = require('body-parser') // send variables to server
var Waterline = require('waterline')

var fs = require('fs') // used to read directries or files

// global npms
var _ = require('lodash')
var async = require('async')

// application configuration files
var db = require('./config/custom/db.js')
var routes = require('./config/custom/routes.js')
var appModels = require('./config/custom/models.js')
var appServices = require('./config/custom/services.js')

var repositoryCollection = require('./api/repositories/RepositoryCollection.js');

var bootstrap = require('./config/bootstrap.js');
var orm = new Waterline();
var mongoAdapter = require('sails-mongo');
var dbInfo = require('./config/db.js');

// helper functions, prototype extensions
require('./config/protos.js')

var config = {
	// setup Adapters; creates named adapters that have have been required
	adapters: {
		'default': mongoAdapter,
		 mongo: mongoAdapter,
	},

	// build connections config; setup connections using the named adapter configs
	connections: {},

	defaults: {
		migrate: 'alter'
	}

};

Object.keys(dbInfo).forEach(function (key) {
	config.connections[key] = dbInfo[key];
});

global.async = async;
global._ = _;

orm = appModels.init(Waterline, orm);
// start express
var app = express();

orm.initialize(config, function (err, models) {
	if(err) throw err;

	// make async and _ available globally
 
	global.custom = {};

	
	// get all models and make them available globally
	global.models = models.collections;

	// setup repos, the abstraction layer between the ORM and the applicaiton
	global.$ = repositoryCollection.init();

	// setup services
	appServices = appServices.init();
	Object.keys(appServices).forEach(function (index) {
		global[index] = appServices[index];
	});

	// setup view engine
	app.set('views', path.join(__dirname, 'api/views'));
	app.set('view engine', 'EJS');

	// setup assets in public folder
	//app.use(bodyParser.json());
	app.use(bodyParser.urlencoded({ extended: false }));
	app.use(cookieParser());
	app.use(express.static(path.join(__dirname, 'public')));
	app.use(methodOverride('X-HTTP-Method-Override'));

	// use custom routing with express
	routes.init(app);

	new bootstrap.bootstrap(function () {
		var server = app.listen(3000, function () {
			server.setMaxListeners(0);
			
			var host = 'localhost',
				port = server.address().port;

			console.log('listening at http://%s:%s', host, port);
		});
	});
})