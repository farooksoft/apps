/**
* This script executes before the application launches, all initializations should be done here
*
*/
module.exports.bootstrap = function(cb) {
	SeedDatabaseService.seedDatabase(function () {
		return cb()
	})
}
