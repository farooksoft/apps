module.exports = {
	
	mongo: {
      adapter: 'mongo',
      host: 'localhost',
      user: '',
	  password: '',
	  port: 27017,
      database: 'movie_library'
    }
}