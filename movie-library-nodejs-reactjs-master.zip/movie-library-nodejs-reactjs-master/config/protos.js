Array.prototype.clean = function() {
	var i = this.length;
	var clean = []
	while (i--) {
		if (this[i]) {
			clean.push(this[i])
		}
	}
	return clean;
}

String.prototype.ucFirst = function() {
	var capitalize = function() {
		var _self = this
		_.each(_self,function(word, key) {
			var word_array = word.split('')
			var fChar = word_array.shift()
			var ucFWord = fChar.toUpperCase()+word_array.join('');
			_self[key] = ucFWord
		})
	}
	
	var string_array = this.split(' ')
	capitalize.call(string_array)
	string_array = string_array.join(' ')

	string_array = string_array.split('-')
	capitalize.call(string_array)
	string_array = string_array.join('-')

	return string_array
}

Array.prototype.contains = function(obj) {
	if(!obj) return false;
	var i = this.length;
	while (i--) {
		if (this[i].trim().toLowerCase() === obj.trim().toLowerCase()) {
			return true;
		}
	}
	return false;
}
