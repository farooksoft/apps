var routes = {
	'get /': 'IndexController.index',
	'get /movies/collection': 'MoviesController.collection',
	'post /movies/add': 'MoviesController.add',
	'get /genres/collection': 'GenresController.collection',
	'get /test': 'IndexController.test'
}

module.exports = routes