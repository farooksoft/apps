/**
* Main application view component that contains collection, search and add movie boxes
*
*/
var MovieLibrary = React.createClass({
	getInitialState: function () {
		return {
			'movies' : movies,
			'results' : movies,
			'showingFullLibrary' : true
		}
	},

	componentDidMount: function () {
		var self = this;
		var filter = {
			'title' : $('#search-title'),
			'year' : $('#search-year'),
			'rating' : $('#search-rating'),
			'genre' : $('#search-genre'),
			'actors' : $('#search-actor')
		};
		for(property in filter) {
			$('#' + filter[property].attr('id')).change(function (e) {
				self.searchMovies();
		    	return false;
			});
		}
	},

	updateMovies: function (movie) {
		var library = this.state.movies;
		var searchTitle = movie.title.toLowerCase();
		var searchId = movie.id;
		var fromServer = typeof searchId != "undefined";
		var movieExists = false;

		var numberOrNull = function (numString) {
			var numOrNull = parseInt(numString)
			if (isNaN(numOrNull)) { numOrNull = null }
			return numOrNull
		}

		for (i = 0; i < library.length; i++) {
			var titleMatch = library[i].title.toLowerCase() == searchTitle;
			var hasId = typeof library[i].id != "undefined";

			var updateFromServer = titleMatch && hasId && fromServer && searchId == library[i].id;
			var updateFromLocal = titleMatch && hasId && !fromServer;

			// replace local data with server data
			if (titleMatch && !hasId && fromServer) {
				movieExists = true;
				library[i] = movie;
				return 'updated';
			}
			// update with local or server data
			if (updateFromServer || updateFromLocal) {
				movieExists = true;
				var updateData = false;

				var combineUnique = function (first, second) {
					var result = first.concat(second);

					for (var i = 0; i < result.length; i++) {
						for (var j = i + 1; j < result.length; j++) {
							if (result[i].name.toLowerCase() == result[j].name.toLowerCase()) {
								result.splice(j--, 1);
							}
						}
					}

					return result;
				};

				if (!library[i].year && movie.year) {
					library[i].year = movie.year;
					updateData = true;
				} else if (!library[i].rating && movie.rating) {
					library[i].rating = movie.rating;
					updateData = true;
				} else if (library[i].genre.length != movie.genre.length) {
					if (fromServer) {
						library[i].id = movie.id;
					}
					var genre = combineUnique(library[i].genre, movie.genre);
					library[i].genre = genre;
					
					updateData = true;
				} else if (library[i].actors.length != movie.actors.length) {
					if (fromServer) {
						library[i].id = movie.id;
					}
					var actors = combineUnique(library[i].actors, movie.actors);
					library[i].actors = actors;

					updateData = true;
				}

				if (updateData) {
					return 'updated';
				} else {
					return false;
				}
			}

			// movie exists locally, and doesn't need to be updated
			if (titleMatch && !fromServer) {
				movieExists = true;
				return false;
			}
		}

		// add movie since it doesn't exist in local collection
		if (!movieExists) {
			library.push(movie);
			return 'added';
		}

		return false;
	},

	searchMovies: function () {
		var searchFilter = this.state.searchFilter;
		var filter = {
			'title' : $('#search-title').is(":checked"),
			'year' : $('#search-year').is(":checked"),
			'rating' : $('#search-rating').is(":checked"),
			'genre' : $('#search-genre').is(":checked"),
			'actors' : $('#search-actor').is(":checked")
		};

		var searchText = $('#search-text').val().trim();
		var searchRegex = RegExp(searchText, 'i');

		var library = this.state.movies;
		var results = [];
		var showingFullLibrary = false;
		var ignoreFilter = !filter.title && !filter.year && !filter.rating && !filter.genre && !filter.actor;

		// prepare search results
		for (i = 0; i < library.length; i++) {
			var currentMovie = library[i];
			var lastMovie = {};
			var addedCurrentMovie = false;
			// if no search text is entered, we will show the whole collection
			if (searchText == '') {
				results.push(currentMovie);
				continue;
			}

			// iterate through movie properties to match search text and push movie to results if so
			for (var property in currentMovie) {
				if (results.length > 0) {
					lastMovie = results[results.length - 1];
				}

				addedCurrentMovie = lastMovie.title === currentMovie.title;
				if (addedCurrentMovie) {
					break;
				}
				if (filter[property] || ignoreFilter) {
					if (property == 'genre' || property == 'actors') {
						var list = currentMovie[property];
						for (j = 0; j < list.length; j++) {
							if (searchRegex.test(list[j].name)) {
								results.push(currentMovie);
								break;
							}
						}
					} else {
						if (searchRegex.test(currentMovie[property])) {
							results.push(currentMovie);
							break;
						}
					}
				}
			}
		}

		if (movies.length == results.length) {
			showingFullLibrary = true;
		}

		this.setState({
			'movies' : this.state.movies,
			'results' : results,
			'showingFullLibrary' : showingFullLibrary
		});
	},

	showCollection: function () {
		// clear search form
		$('#search-text').val('');
		$searchFitler = $('#search-filter input[type="checkbox"]');
		$searchFitler.each(function () {
			$(this).attr('checked', false);
		});

		this.setState({
			'movies' : this.state.movies,
			'results' : this.state.movies,
			'showingFullLibrary' : true
		});
	},

	render: function () {
		var resultNodes = this.state.results.map(function (movie) {
			return (
				<SearchResultSingleMovie title={movie.title} year={movie.year} rating={movie.rating} genre={movie.genre} actors={movie.actors} />
			);
		});
		return (
			<div id="movie-library">
				<h1>Awesome Movie Library <small>powered by MERN (MongoDB, Express, Nodejs & Reactjs)!</small></h1>
				<div id="movie-collection" className="row panel panel-default">
					<div className="panel-heading">Movie Collection</div>
					<div className="panel-body">
						<MovieSearchBox searchMovies={this.searchMovies} showCollection={this.showCollection} />
						<div className="col-md-12">
							<ul className="movie-result-list">{resultNodes}</ul>
						</div>
					</div>
				</div>
				<AddMovieBox showingFullLibrary={this.state.showingFullLibrary} showCollection={this.showCollection} searchMovies={this.searchMovies} updateMovies={this.updateMovies} />
			</div>
		);
	}
});


/**
* Search form for movies
*
*/
var MovieSearchBox = React.createClass({
	componentDidMount: function () {
		var self = this;
		$('#search-text').keydown(function (event) {
			if (event.keyCode == 13) {
		    	event.preventDefault();
				self.props.searchMovies();
			} else {
				self.props.searchMovies();
			}
		});

		$('#search-text').keyup(function (event) {
			self.props.searchMovies();
		});
	},

	render: function () {
		return (
			<div id="search-box" className="row">
				<form role="form" className="form-inline" id="search-form" onSubmit={this.props.searchMovies}>
					<div className="col-md-12">
						<div className="form-group">
							<input type="text" className="form-control" id="search-text" placeholder="Search Movies" />
							<button type="button" className="btn btn-default btn-warning" onClick={this.props.showCollection}>Clear</button>
							<button type="button" className="btn btn-default btn-info" onClick={this.props.showCollection}>Show Collection</button>
						</div>
					</div>
					<div className="col-md-12">
						<div className="form-group" id="search-filter">
							<div className="checkbox">
								<label className="control-label"><input type="checkbox" id="search-title" /> Title</label>
							</div>
							<div className="checkbox">
								<label className="control-label"><input type="checkbox" id="search-year" /> Year</label>
							</div>
							<div className="checkbox">
								<label className="control-label"><input type="checkbox" id="search-rating" /> Rating</label>
							</div>
							<div className="checkbox">
								<label className="control-label"><input type="checkbox" id="search-genre" /> Genre</label>
							</div>
							<div className="checkbox">
								<label className="control-label"><input type="checkbox" id="search-actor" /> Actor</label>
							</div>
						</div>
					</div>
				</form>
			</div>
		);
	}
});


/**
* Creates markup for a single item in search results
*
*/
var SearchResultSingleMovie = React.createClass({
	render: function () {
		var genreList = this.props.genre,
			genreString = '',
			actorList = this.props.actors,
			actorString = '';

		for (i = 0; i < genreList.length; i++) {
			if (i == 0) {
				genreString += genreList[i].name;
			} else {
				genreString += ', ' + genreList[i].name;
			}
		}

		for (i = 0; i < actorList.length; i++) {
			if (i == 0) {
				actorString += actorList[i].name;
			} else {
				actorString += ', ' + actorList[i].name;
			}
		}

		return (
			<li className="movie-result">
				<h4 className="title">{this.props.title}</h4>
				<dl className="dl-horizontal">
					<dt>Year</dt>
					<dd>{this.props.year}</dd>
					<dt>Rating</dt>
					<dd>{this.props.rating}</dd>
					<dt>Genre</dt>
					<dd>{genreString}</dd>
					<dt>Actors</dt>
					<dd>{actorString}</dd>
				</dl>
			</li>
		);
	}
});


/**
* Form for adding movies to collection
*
*/
var AddMovieBox = React.createClass({
	createMovie: function () {
		// get all movie information and create an object to inject locally / pass to an API
		var $basicInfo = $('#basic-movie-info');
		var title = $basicInfo.find('input.title').val().trim(),
			year = $basicInfo.find('input.year').val().trim(),
			rating = $basicInfo.find('select.rating').val(),
			genre = [],
			actors = [];

		// do not create movie if the title is missing, the minimum required field
		if (title == '') { return false; }

		var $genreCheckboxes = $('#genre-list input[type="checkbox"]');
		$genreCheckboxes.each(function () {
			if ($(this).is(':checked')) {
				var id = $(this).attr('data-id');
				var name = $(this).attr('data-name');
				
				genre.push({ 'id': id, 'name': name });
			}

		});

		var $actorList = $('#actor-list li .actor-name');
		$actorList.each(function () {
			var name = $(this).attr('data-name');
			actors.push({ 'id': null, 'name': name });
		});

		return {
			'title' : title,
			'year' : year,
			'rating' :  rating,
			'genre' : genre,
			'actors' : actors
		};
	},

	clearInputs: function () {
		var $basicInfo = $('#basic-movie-info');
		$basicInfo.find('input.title').val('');
		$basicInfo.find('input.year').val('');
		$basicInfo.find('select.rating').val('1');

		$('#actor-list ul').html('');
		var $genreCheckboxes = $('#genre-list input[type="checkbox"]');
		$genreCheckboxes.each(function () {
			$(this).attr('checked', false);
		});

	},

	addMovie: function () {
		var self = this,
			movie = this.createMovie(),
			defaultError = 'Please enter a valid title.',
			defaultSuccess = 'Movie added successfully!';

		var showWarning = function () {
			$('#add-movie .alert-danger').fadeOut();
			$('#add-movie .alert-success').fadeOut();
			$('#add-movie .alert-warning').fadeIn(200).fadeOut(5000);
		}
		
		if (!movie) {
			$('#add-movie .alert-danger').html(defaultError);
			$('#add-movie .alert-danger').fadeIn();
			return;
		} else {
			// adding data locally
			var movieAdded = self.props.updateMovies(movie);
			if (movieAdded) {
				if (self.props.showingFullLibrary) {
					self.props.showCollection();
				} else {
					self.props.searchMovies();
				}
			} else {
				// movie is already in collection
				showWarning();
				$('#add-movie .alert-danger').fadeOut();
				self.clearInputs();
			}
			
			// update globally
			if (movieAdded) {
				var route = '/movies/add';
				$.ajax({
					url: baseUrl + route,
					data: JSON.stringify(movie),
					method: 'POST',

					success: function (jsonData, textStatus, jqXHR) {
						$('#add-movie .alert-danger').fadeOut();
						movieAdded = self.props.updateMovies(jsonData.movie);
						if (movieAdded = 'added') {
							var successMessage = '<strong>' + jsonData.message + '</strong>';
							if (jsonData.message == 'Nothing to save.') {
								showWarning();
							} else {
								$('#add-movie .alert-success').html(successMessage).fadeIn(200).fadeOut(5000);
							}
						} else if (movieAdded = 'updated') {
							showWarning();
						}
						self.clearInputs();
						self.props.searchMovies();
					},

					error: function (jqXHR, textStatus, errorThrown) {
						movies.pop();
						$('#add-movie .alert-success').hide();
						$('#add-movie .alert-danger').html(textStatus);
					}
				});
			}
		}
	},

	render: function () {
		return (
			<div id="add-movie" className="row panel panel-default">
				<div className="panel-heading">Add Movie to Collection</div>
				<div className="panel-body">
					<div className="alert alert-success" role="alert">Movie added successfully!</div>
					<div className="alert alert-warning" role="alert"><strong>Movie already exists in collection.</strong></div>
					<div className="alert alert-danger" role="alert">Please enter a valid title.</div>
					<form role="form" className="form-inline">
						<BasicMovieInfo />
						<GenreList />
						<AddCastBox />
						<div className="col-md-12">
							<button type="button" className="btn btn-default btn-success btn-block" id="add-movie-button" onClick={this.addMovie}>Add Movie</button>
						</div>
					</form>
				</div>
			</div>
		);
	}
});


/**
* Add movie form component for basic movie information (Title, Year & Rating)
*
*/
var BasicMovieInfo = React.createClass({
	render: function () {
		return (
			<div className="col-md-12" id="basic-movie-info">
				<div className="form-group">
					<label for="title">Title:</label>
					<input type="text" className="form-control title" />
				</div>
				<div className="form-group">
					<label for="year">Year:</label>
					<input type="number" className="form-control year" />
				</div>
				<div className="form-group">
					<label for="rating" className="rating">Rating:</label>
					<select className="form-control rating">
						<option value="1">1</option>
						<option value="2">2</option>
						<option value="3">3</option>
						<option value="4">4</option>
						<option value="5">5</option>
					</select>
				</div>
			</div>
		);
	}
});


/**
* Add movie form component for selecting genres
*
*/
var GenreList = React.createClass({
	render: function () {
		var genreNodes = genres.map(function (genre) {
			return (
				<MovieGenre genre={genre} />
			);
		});

		return (
			<div className="col-md-12" id="genre-list">
				<div className="form-group">
					<label for="genre">Genre:</label>
					<div className="form-group genres">
						{genreNodes}
					</div>
				</div>
			</div>
		);
	}
});


/**
* Add movie form component for generating markup for a single genres
*
*/
var MovieGenre = React.createClass({
	render: function () {
		var genre = this.props.genre;
		return (
			<div className="checkbox">
				<label className="control-label"><input type="checkbox" data-id={genre.id} data-name={genre.name} /> {genre.name}</label>
			</div>
		);
	}
});


/**
* Add movie form component for adding cast list
*
*/
var AddCastBox = React.createClass({
	getInitialState: function () {
		return { 'actors' : [] }
	},

	componentDidMount: function () {
		var self = this;
		$('#add-actor-name').keydown(function (event) {
			if (event.keyCode == 13) {
		    	event.preventDefault();
				self.addActor();
		    	return false;
			}
		});
	},

	addActor: function () {
		var $actorNameInput = $('#add-actor-name');
		var actorName = $actorNameInput.val().trim();
		if (actorName == '') {
			return;
		}
		var actors = this.state.actors;

		actors.push({ 'id': null, 'name': actorName });
		this.setState({ 'actors' : actors });
		$actorNameInput.val('');
	},

	removeActor: function (actor) {
		var actors = this.state.actors,
			index = null;
		for (i = 0; i < actors.length; i++) {
			if (actors[i].name == actor.name) {
				index = i;
				break;
			}
		}
		
		if (index > -1) {
			actors.splice(index, 1);
		}
		this.setState({ 'actors' : actors });
	},

	render: function () {
		return (
			<div className="col-md-12" id="cast">
				<div className="form-group">
					<label for="actors">Cast:</label>
					
					<div id="add-actor">
						<input type="text" className="form-control actors" placeholder="Name" id="add-actor-name" />
						<button type="button" className="btn btn-default" id="add-actor-button" onClick={this.addActor}>Add Actor</button>
					</div>

					<CastList actors={this.state.actors} removeActor={this.removeActor} />
				</div>
			</div>
		);
	}
});


/**
* Add movie form component for generating user input cast
*
*/
var CastList = React.createClass({
	render: function () {
		var removeActorFunction = this.props.removeActor;
		var actorNodes = this.props.actors.map(function (actor) {
			return (
				<CastMember actor={actor} removeActor={removeActorFunction} />
			);
		});
		return (
			<div id="actor-list">
				<ul>
					{actorNodes}
				</ul>
			</div>
		);
	}
});


/**
* Add movie form component for generation mark up for each actor input by user
*
*/
var CastMember = React.createClass({
	render: function () {
		var actor = this.props.actor;
		return (
			<li>
				<button type="button" className="btn btn-default btn-xs btn-danger" aria-label="Left Align" onClick={this.props.removeActor.bind(this, actor)}>
					<span className="glyphicon glyphicon-remove" aria-hidden="true"></span>
				</button>
				<span className="actor-name" data-name={actor.name} >{actor.name}</span>
			</li>
		);
	}
});

React.render(
	<MovieLibrary />,
	document.getElementById('content')
);