### Install local modules
* `npm install`

### To run locally
* `npm run start`
* `open http://localhost:8000`

### To run in production
* `npm run production`
