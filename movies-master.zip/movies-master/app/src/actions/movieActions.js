import AppDispatcher from '../dispatchers/AppDispatcher'
import movieConstants from '../constants/movieConstants'

export default {
  gotMovies:(movies) => {
    AppDispatcher.dispatch({
      actionType:movieConstants.MOVIE_GET,
      movies: movies
    })
  },

  detailMovie:(movie) => {
    AppDispatcher.dispatch({
      actionType: movieConstants.MOVIE_DETAIL,
      movie: movie
    })
  }
}
