import React,{Component} from 'react'
import mui from 'material-ui'
import AppBar from 'material-ui/lib/app-bar'
import RaisedButton from 'material-ui/lib/raised-button'
import ThemeManager from 'material-ui/lib/styles/theme-manager'
import CustomTheme from '../../themes/theme1'
import Movie from './movie'
import MovieList from './MovieList'
import MovieDetail from './MovieDetail'

class AuthenticatedApp extends Component {

  static childContextTypes = {
    muiTheme: React.PropTypes.object
  }

  constructor(){
    super()
  }

  getChildContext(){
    return {
      muiTheme: ThemeManager.getMuiTheme(CustomTheme)
    }
  }

  home = () => {
    console.log("home")
  }

  render(){
    return(
      <div>
        <AppBar onTitleTouchTap={this.home} title="Movies App" showMenuIconButton={false}/>
        <div style={{
            display:"flex",
            flexFlow: "row wrap",
            maxWidth: 1200,
            width: "100%",
            margin: "30px auto 30px"
          }}>
          {this.props.children}
        </div>
      </div>
    )
  }
}

export default AuthenticatedApp
