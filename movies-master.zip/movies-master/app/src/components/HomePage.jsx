import React,{Component} from 'react'
import MovieList from './MovieList'

export default class HomePage extends Component {
  render(){
    return <MovieList />
  }
}
