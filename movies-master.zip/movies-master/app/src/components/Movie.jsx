import React,{Component} from 'react'
import GridTile from 'material-ui/lib/grid-list/grid-tile'
import IconButton from 'material-ui/lib/icon-button'
import StarBorder from 'material-ui/lib/svg-icons/toggle/star-border'
import movieActions from '../actions/movieActions'

export default class Movie extends Component {

  static contextTypes = {
    router: React.PropTypes.object.isRequired
  }

  viewMovieDetail = () => {
    movieActions.detailMovie(this.props)
    // console.log(this.props)
    this.context.router.replace("/movie")
  }

  render(){
    return (
      <GridTile
        onClick={this.viewMovieDetail}
        style={{cursor:"pointer"}}
        title={this.props.title}
        subtitle={<span>by <b>{this.props.author}</b></span>}
        actionIcon={<IconButton><StarBorder color="white"/></IconButton>} >
        <img src={this.props.img} />
      </GridTile>
    )
  }
}
