import React from 'react'
import Card from 'material-ui/lib/card/card'
import CardActions from 'material-ui/lib/card/card-actions'
import CardHeader from 'material-ui/lib/card/card-header'
import CardMedia from 'material-ui/lib/card/card-media'
import CardTitle from 'material-ui/lib/card/card-title'
import FlatButton from 'material-ui/lib/flat-button'
import CardText from 'material-ui/lib/card/card-text'
import movieStore from '../stores/movieStore'
import movieActions from '../actions/movieActions'

export default class MovieDetail extends React.Component {

  static contextTypes = {
    router: React.PropTypes.object.isRequired
  }


  constructor(){
    super()
    this.state = this._getMovieDetailState()
  }

  _getMovieDetailState(){
    return movieStore.movieSelected
  }

  componentDidMount(){
    movieStore.addChangeListener(this._onChange)
  }

  componentWillUnmount(){
    movieStore.removeChangeListener(this._onChange)
  }


  _onChange = () => {
    this.setState(this._getMovieDetailState())
  }

  goToHome = () =>{
    this.context.router.replace("/")
  }

  render(){
    return (
      <Card style={{width:"80%",margin:"0 auto"}}>

        <CardMedia
          overlay={<CardTitle title={this.state.title} subtitle="Con 25 likes" />}
        >
          <img src={this.state.img} />
        </CardMedia>
        <CardTitle title="Card title" subtitle="Card subtitle" />
        <CardText>
          {this.state.description}
        </CardText>
        <CardActions>
          <FlatButton onClick={this.goToHome} label="Volver" />
        </CardActions>
      </Card>
    )
  }
}
