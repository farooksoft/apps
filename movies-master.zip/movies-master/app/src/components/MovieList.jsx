import React,{Component} from 'react'
import Movie from './movie'
import GridList from 'material-ui/lib/grid-list/grid-list'
import movieStore from '../stores/movieStore'
import movieActions from '../actions/movieActions'
import movieService from '../services/movieService'

const styles = {
  root: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-around',
    margin: "0 auto"
  },
  gridList: {
    width: 800,
    height: 800,
    overflowY: 'auto',
    marginBottom: 24,
  },
}

export default class MovieList extends Component {

  constructor(){
    super()
    this.state = this._getMoviesState()
  }

  _getMoviesState(){
    return {
      movies: movieStore.movies
    }
  }

  getMovies(){
    movieService.getMovies()
      .then( movies => {
        movieActions.gotMovies(movies)
      })
      .catch( error => {
        console.log(error)
      })
  }

  componentDidMount(){
    this.getMovies()
    movieStore.addChangeListener(this._onChange)
  }

  componentWillUnmount(){
    movieStore.removeChangeListener(this._onChange)
  }

  _onChange = () => {
    this.setState(this._getMoviesState())
  }

  render(){
      const movies = this.state.movies.map( (movie,index) => {
        return <Movie
          key={index}
          title={movie.title}
          author={movie.producedBy}
          img={movie.bannerUrl}
          description={movie.Description}
          />
      })
      return (
        <div style={styles.root}>
          <GridList
            cellHeight={240}
            style={styles.gridList}>
            {movies}
          </GridList>
        </div>
      )
  }
}
