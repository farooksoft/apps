import React from 'react'
import {hashHistory,Router,Route,Link,IndexRoute} from 'react-router'
import AuthenticatedApp from '../components/AuthenticatedApp'
import HomePage from '../components/HomePage'
import MovieDetail from '../components/MovieDetail'

class NotFoundPage extends React.Component {
  render(){
    return <h1>Page not found</h1>
  }
}

let routes = (
  <Router history={hashHistory}>
    <Route path="/" component={AuthenticatedApp} >
      <IndexRoute  component={HomePage} />
      <Route path="/movie" component={MovieDetail} />
    </Route>
    <Route path="*" component={NotFoundPage} />
  </Router>
)

export default routes
