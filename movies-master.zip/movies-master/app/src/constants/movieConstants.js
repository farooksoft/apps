var BASE_URL = 'https://webtask.it.auth0.com/api/run/wt-alfredo_villagomez_m-gmail_com-0/'
export default {
  BASE_URL: BASE_URL,
  MOVIE_URL: BASE_URL + 'getMovies',
  MOVIE_GET: 'MOVIE_GET',
  MOVIE_DETAIL: 'MOVIE_DETAIL'
}
