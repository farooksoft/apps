import request from 'reqwest'
import when from 'when'
import movieConstants from '../constants/movieConstants'

class MovieService {

  getMovies(){
    return when(request({
      url: movieConstants.MOVIE_URL,
      method: "GET",
      crossOrigin: true
    }))
  }
}


export default new MovieService()
