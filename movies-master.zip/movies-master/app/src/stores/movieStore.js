import BaseStore from './baseStore'
import movieConstants from '../constants/movieConstants'

class MovieStore extends BaseStore {

  constructor(){
    super()
    this.subscribe( () => this._registerToActions.bind(this) )
    this._movies = []
    this._movieSelected= null
  }

  _registerToActions(action){
    switch (action.actionType) {
      case movieConstants.MOVIE_GET:
        this._movies = action.movies
        this.emitChange()
        break
      case movieConstants.MOVIE_DETAIL:
        this._movieSelected = action.movie
        this.emitChange()
        break
      default:
        break

    }
  }

  get movies(){
    return this._movies
  }

  get movieSelected(){
    return this._movieSelected
  }
}

export default new MovieStore()
