var HtmlWebpackPlugin = require("html-webpack-plugin")
  HtmlWebpackPluginConfig = new HtmlWebpackPlugin({
    template: __dirname + "/app/index.html",
    filename: "index.html",
    inject: "body"
  })

module.exports = {

  resolve: {
    extensions: ['','.jsx','.js']
  },

  entry:"./app/src/app.jsx",

  output:{
    path: __dirname + "/build",
    filename: "app_bundle.js"
  },

  module:{
    loaders:[
      {
        test: /(\.js|\.jsx)$/,
        loader: "babel-loader",
        query: { presets: ['es2015','react','stage-0']}
      }
    ]
  },

  plugins: [HtmlWebpackPluginConfig]
}
