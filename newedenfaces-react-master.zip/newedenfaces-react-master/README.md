# New Eden Faces (React)

[![Donate](https://img.shields.io/badge/paypal-donate-blue.svg)](https://paypal.me/sahat) [![Book session on Codementor](https://cdn.codementor.io/badges/book_session_github.svg)](https://www.codementor.io/sahatyalkabov?utm_source=github&utm_medium=button&utm_term=sahatyalkabov&utm_campaign=github)

**Source code** for [
Create a character voting app using React, Node.js, MongoDB and Socket.IO](http://sahatyalkabov.com/create-a-character-voting-app-using-react-nodejs-mongodb-and-socketio/).

![](https://lh3.googleusercontent.com/bTN84YkcbO_gXZm4qOrOYVTwUgwkOsrFfv8nrUe7aew=w2080-h1470-no)
