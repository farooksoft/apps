#nodejs-movie-app
A complete MVC application built in nodejs - expressjs framework and tested with mocha.

Blog post [www.eyasranjous.info/post/developing-web-application-nodejs-mongodb](http://www.eyasranjous.info/post/developing-web-application-nodejs-mongodb)

## Requirements
- download & install [Nodejs](https://nodejs.org/download/)
- download & install [MongoDB](https://www.mongodb.org/downloads)
- install grunt-cli ```npm install -g grunt-cli```

## Install & Run
Clone the repo
```
git clone https://github.com/eyas-ranjous/nodejs-movie-app
```

navigate to the project folder and then install the dependencies
```
npm install
```

set environment as development (can be skipped, default is development)
```
export NODE_ENV=development // use git bash on windows
```

start development db
```
grunt mongo // make sure /data/db directory exists in your system
```

start the app development server
```
npm start
```

visit localhost:3000 and you should get the home page:

![homepage](http://i.imgur.com/YVXq7OW.png "homepage")


## Testing
set environment as testing
```
export NODE_ENV=testing
```

lint
```
grunt build
```

starting the test db
```
grunt mongo
```

running the tests
```
grunt test
```
