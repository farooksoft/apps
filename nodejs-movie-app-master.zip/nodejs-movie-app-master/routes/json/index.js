// export routes object
module.exports = {
    home: require('./home'),
    movies: require('./movies')
}