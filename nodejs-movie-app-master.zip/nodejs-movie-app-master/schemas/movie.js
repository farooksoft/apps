// movie schema object
module.exports = {
    title: String,
    imdbId: String,
    duration: Number,
    year: Number,
    description: String,
    director: String,
    posterUrl: String
};