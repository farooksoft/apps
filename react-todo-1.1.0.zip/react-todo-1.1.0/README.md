# react-todo
Another basic todo app in React and Flux

#### Quick Start

```
npm install
npm start
```

Open the `index.html` file.

